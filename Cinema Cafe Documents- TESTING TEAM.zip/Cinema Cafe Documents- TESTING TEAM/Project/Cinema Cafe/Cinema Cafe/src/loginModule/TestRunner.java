package loginModule;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="Feature files",glue="loginModule",tags="@CinemaCafePage",format = {"pretty", "html:target/CinemaCafe"} )

public class TestRunner {
	


}
