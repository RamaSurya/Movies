package loginModule;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ObjectAccess {
	static Properties p= new Properties();
	static File f ;
	
	 public void openProperty(String m1) throws IOException {
		f = new File("C:/Project/Cinema Cafe/Cinema Cafe/src/com/pom/"+m1+".properties");
		 FileInputStream fin = new FileInputStream(f);
			p.load(fin);
	}
	
	 static public String geturl(){
		 return p.getProperty("ur");
	 }
	 
	 static public String getexl(){
		 return p.getProperty("exl");
	 }
	
	 
	 
	 public ObjectAccess() throws IOException {
		
	}
	
	
	
	static public By getlocator(String n){
		String n1=p.getProperty(n);
		String ns[]=n1.split(",");
		String loc=ns[0];
		String val=ns[1];
		
		if (loc.equals("id")) {
			return(By.id(val));
		}
		else if (loc.equals("name")) {
			return(By.name(val));
		}
		else if (loc.equals("cssSelector")) {
			return(By.cssSelector(val));
		}
		
		else if (loc.equals("xpath")) {
			return(By.xpath(val));
		}
		else if (loc.equals("tagName")) {
			return(By.tagName(val));
		}
		else {
			return null;
		}
		
		
		
	}

	public static void main(String[] args) throws IOException {
	ObjectAccess ob=new ObjectAccess();
	}

}

