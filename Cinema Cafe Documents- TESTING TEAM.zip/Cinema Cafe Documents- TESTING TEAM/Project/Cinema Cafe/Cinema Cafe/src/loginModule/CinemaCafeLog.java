package loginModule;

import java.awt.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.model.ConvertAnchor;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.velocity.runtime.parser.node.GetExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.server.handler.GetCurrentUrl;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.sourceforge.htmlunit.corejs.javascript.ast.GeneratorExpressionLoop;

public class CinemaCafeLog extends ObjectAccess{
		public CinemaCafeLog() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
		
		
		static String url="http://172.16.170.58/cinemacafe1";
		static String excel="C:/Project/Cinema Cafe/Cinema Cafe/Excel Files/Cinema Cafe.xlsx";
		
		
		static WebDriver driver=new FirefoxDriver();
		static File f=new File(excel);
		 static  FileInputStream f1;
			static XSSFWorkbook wb;
			static XSSFSheet sh;
			static public String  read(int r,int c, String sht) throws IOException
			{
				 FileInputStream f1=new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(f1);
					XSSFSheet sh=wb.getSheet(sht);
					String u="";
				          try{
				        	  if(sh.getRow(r).getCell(c).getCellType()==0)
								{
									int m=(int) sh.getRow(r).getCell(c).getNumericCellValue();
									u=String.valueOf(m);
								}
								else
								{
									u=sh.getRow(r).getCell(c).getStringCellValue();
								}
							}
							catch(Exception e)
							{
								if(e.equals("NullPointerException"))
									u=null;
							}
					//wb.close();
					return u;
					
			}
			public void write(int r,int c,String s, String sht) throws IOException
			{
				 FileInputStream f1=new FileInputStream(f);
					XSSFWorkbook wb=new XSSFWorkbook(f1);
					XSSFSheet sh=wb.getSheet(sht);
					try {
						sh.getRow(r).createCell(c).setCellValue(s);
					} 
					catch (NullPointerException e) {
						sh.getRow(r).createCell(c).setCellValue(Integer.parseInt(s));	
						}
					FileOutputStream fo=new FileOutputStream(new File(p.getProperty("exl")));
					  wb.write(fo);
					  //wb.close();
			}
		
			
			
			public void status(int r, int c, String sht) throws IOException {
				 if (read(r,c,sht).equals(read(r,(c+1), sht))) {
				    	write(r, (c+2), "Pass",sht);
					} else {
						File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
						FileUtils.copyFile(src, new File("C:/Project/Cinema Cafe/Cinema Cafe/Screenshots/Cinema Cafe Page/"+read(r,c,sht)+".png"));
						write(r, (c+2), "Fail",sht);
					}
			}
			
			
	@Given("^User is on the Cinema Cafe Page$")
	public void User_is_on_the_Cinema_Cafe_Page() throws IOException {
		driver.manage().window().maximize();
		openProperty("CinemaCafe");
		driver.get(url);
	    
	}
	

	@When("^the Cinema Cafe Page is open$")
	public void the_Cinema_Cafe_Page_is_open() {
		 driver.get(url);
	    
	}

	@Then("^Title of page should be Cinema Cafe$")
	public void Title_of_page_should_be_Cinema_Cafe() throws IOException {
	    write(1, 2, driver.getTitle(),"GUI");  
	  status(1, 1, "GUI");
	  
	}

	@When("^User enters valid User ID and Password present in Database$")
	public void User_enters_valid_User_ID_and_Password_present_in_Database() throws IOException {
		   driver.findElement(getlocator("uid")).sendKeys(read(1,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(1,1,"data"));
		   driver.findElement(getlocator("log")).click();
		    
	}

	@Then("^Redirect to the Admin Home or Customer Home$")
	public void Redirect_to_the_Admin_Home_or_Customer_Home() throws IOException {
		write(1, 3, driver.getTitle(),"data");
			status(1,2,"data");
	}

	@When("^User enters Password$")
	public void User_enters_Password() throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(2,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(2,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - User ID is blank.Please provide a valid Username.$")
	public void User_gets_message_User_ID_is_blank_Please_provide_a_valid_Username() throws IOException {
	    write(2, 3,driver.findElement(getlocator("blkuid")).getText(),"data");
	    status(2,2,"data");
	}

	@When("^User enters User ID$")
	public void User_enters_User_ID() throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(3,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(3,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - Password is blank.Please provide a valid Password.$")
	public void User_gets_message_Password_is_blank_Please_provide_a_valid_Password() throws IOException {
		write(3, 3, driver.findElement(getlocator("blkpwd")).getText(),"data");
		status(3,2,"data");
	}

	@When("^User enters User ID less than (\\d+) character$")
	public void User_enters_User_ID_less_than_character(int arg1) throws IOException {
		   driver.findElement(getlocator("uid")).sendKeys(read(4, 0, "data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(4,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - Please provide a valid Username,less character.$")
	public void User_gets_message_Please_provide_a_valid_Username_less_character() throws IOException {
		write(4, 3, driver.findElement(getlocator("uidless")).getText(),"data");
		status(4,2,"data");
	}

	@When("^User enters User ID more than (\\d+) character$")
	public void User_enters_User_ID_more_than_character(int arg1) throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(5,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(5,1,"data"));
		   driver.findElement(getlocator("log")).click();
	    
	}

	@Then("^User gets message - Please provide a valid Username, more character.$")
	public void User_gets_message_Please_provide_a_valid_Username_more_character() throws IOException {
		write(5, 3, driver.findElement(getlocator("uidmore")).getText(),"data");
		status(5,2,"data");
	}

	@When("^User enters Password less than (\\d+) character$")
	public void User_enters_Password_less_than_character(int arg1) throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(6,0,"data"));
 		   driver.findElement(getlocator("pass")).sendKeys(read(6,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - Please provide a valid Password, less character.$")
	public void User_gets_message_Please_provide_a_valid_Password_less_character() throws IOException {
		write(5, 3, driver.findElement(getlocator("passless")).getText(),"data");
		status(6,2,"data");
	}

	@When("^User enters Password more than (\\d+) character$")
	public void User_enters_Password_more_than_character(int arg1) throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(7,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(7,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - Please provide a valid Password, more character.$")
	public void User_gets_message_Please_provide_a_valid_Password_more_character() throws IOException {
		write(7, 3, driver.findElement(getlocator("passmore")).getText(),"data");
		status(7,2,"data");

	}

	@When("^User enters Password with Special Characters$")
	public void User_enters_Password_with_Special_Characters() throws IOException {
		driver.findElement(getlocator("uid")).sendKeys(read(8,0,"data"));
		   driver.findElement(getlocator("pass")).sendKeys(read(8,1,"data"));
		   driver.findElement(getlocator("log")).click();
	}

	@Then("^User gets message - Please provide a valid Password,special character.$")
	public void User_gets_message_Please_provide_a_valid_Password_special_character() throws IOException {
		write(8, 3, driver.getTitle(), "data");
		status(8,2,"data");
	}
	
	@When("^User counts the no. of links$")
	public void User_counts_the_no_of_links() throws IOException  {
		java.util.List<WebElement> lnks=driver.findElements(getlocator("linktag"));
		String act =String.valueOf(lnks.size());
		write(2, 2,act,"GUI");
	}

	@Then("^User gets the no. of links equal to (\\d+)$")
	public void User_gets_the_no_of_links_equal_to(int arg1) throws IOException {
		status(2, 1, "GUI");
	}
	
	@When("^User counts the no. of textboxes$")
	public void User_counts_the_no_of_textboxes() throws IOException {
		java.util.List<WebElement> tb=driver.findElements(getlocator("box"));
		String act =String.valueOf(tb.size());
		write(3, 2,act,"GUI");
	}

	@Then("^User gets the no. of textboxes equal to (\\d+)$")
	public void User_gets_the_no_of_textboxes_equal_to(int arg1) throws IOException {
		status(3, 1, "GUI");
	}

}