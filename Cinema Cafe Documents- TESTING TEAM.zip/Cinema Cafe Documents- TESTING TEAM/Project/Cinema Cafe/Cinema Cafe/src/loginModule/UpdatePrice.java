package loginModule;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UpdatePrice extends ObjectAccess {
	
	public UpdatePrice() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	static String url="http://172.16.170.58/cinemacafe1";
	static String excel="C:/Project/Cinema Cafe/Cinema Cafe/Excel Files/Update Price.xlsx";
	static WebDriver driver=new FirefoxDriver();
	
	static File f=new File(excel);
	 static  FileInputStream f1;
		static XSSFWorkbook wb;
		static XSSFSheet sh;
		public String  read(int r,int c, String sht) throws IOException
		{
			
			  FileInputStream f1=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(f1);
				XSSFSheet sh=wb.getSheet(sht);
				String u="";
			          try
						{
							if(sh.getRow(r).getCell(c).getCellType()==0)
							{
								int m=(int) sh.getRow(r).getCell(c).getNumericCellValue();
								u=String.valueOf(m);
							}
							else
							{
								u=sh.getRow(r).getCell(c).getStringCellValue();
							}
						}
						catch(Exception e)
						{
							if(e.equals("NullPointerException"))
								u=null;
						}
				//wb.close();
				return u;
				
		}
		public void write(int r,int c,String s, String sht) throws IOException
		{
			 FileInputStream f1=new FileInputStream(f);
				XSSFWorkbook wb=new XSSFWorkbook(f1);
				XSSFSheet sh=wb.getSheet(sht);
				try {
					sh.getRow(r).createCell(c).setCellValue(s);
				} 
				catch (NullPointerException e) {
					sh.getRow(r).createCell(c).setCellValue(Integer.parseInt(s));	
					}
				FileOutputStream fo=new FileOutputStream(new File(excel));
				  wb.write(fo);
				  //wb.close();
		}
	
		
		
		public void status(int r, int c, String sht) throws IOException {
			 try {if (read(r,c,sht).equals(read(r,(c+1), sht))) {
			    	write(r, (c+2), "Pass",sht);
				} else {
					File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(src, new File("C:/Project/Cinema Cafe/Cinema Cafe/Screenshots/Update Price Page/"+read(r,c,sht)+".png"));
					write(r, (c+2), "Fail",sht);
				}
				
			} catch (NullPointerException e) {
					write(r, (c+1), "No Error messages",sht);
					File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
					FileUtils.copyFile(src, new File("C:/Project/Cinema Cafe/Cinema Cafe/Screenshots/Update Price Page/"+read(r,c,sht)+".png"));
					write(r, (c+2), "Fail",sht);

			}
		}
		

	@Given("^user should be on the UpdatePrice page$")
	public void user_should_be_on_the_UpdatePrice_page() throws IOException {
		driver.manage().window().maximize();
		driver.get(url);
		openProperty("Updateprice");
		driver.findElement(getlocator("uid")).sendKeys("admin@admin.com");
		   driver.findElement(getlocator("pass")).sendKeys("admin123");
		   driver.findElement(getlocator("log")).click();
		   driver.findElement(getlocator("updateprice")).click();
	    
	}

	@When("^Admin clicks on Home link$")
	public void Admin_clicks_on_Home_link() throws Throwable {
	   
	}

	@Then("^Admin should be Redirected to the Admin Home page$")
	public void Admin_should_be_Redirected_to_the_Admin_Home_page() {
	    
	}

	@When("^Admin clicks on Add Movie link$")
	public void Admin_clicks_on_Add_Movie_link() {
	    
	}

	@Then("^Admin should be Redirected to the Update movie Page$")
	public void Admin_should_be_Redirected_to_the_Update_movie_Page1() {
	    
	}

	@When("^Admin clicks on Update Movie link$")
	public void Admin_clicks_on_Update_Movie_link() {
	    
	}

	@Then("^Admin should be Redirected to  the Update movie Page$")
	public void Admin_should_be_Redirected_to_the_Update_movie_Page(){
	    
	}

	@When("^Admin clicks on Update Price link$")
	public void Admin_clicks_on_Update_Price_link() {
	    
	}

	@Then("^Admin should be Redirected to same \\(Update Price \\)Page$")
	public void Admin_should_be_Redirected_to_same_Update_Price_Page() {
	    
	}

	@When("^Admin clicks on LOGOUT link$")
	public void Admin_clicks_on_LOGOUT_link() {
	    
	}

	@Then("^Admin should be Redirected to the Cinema Cafe Page$")
	public void Admin_should_be_Redirected_to_the_Cinema_Cafe_Page() {
	    
	}

	@When("^Admin selects Seat type and Admin enters Price and Admin clicks on Update button$")
	public void Admin_selects_Seat_type_and_Admin_enters_Price_and_Admin_clicks_on_Update_button() throws IOException {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(1, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(1,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^Admin gets message - Updated the price(\\d+)$")
	public void Admin_gets_message_Updated_the_price(int arg1) throws IOException {
		
	    status(1, 2, "data");
	}

	@When("^Admin selects Seat type and Admin clicks on Update button$")
	public void Admin_selects_Seat_type_and_Admin_clicks_on_Update_button() throws IOException {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(2, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(2,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^Admin gets message - Price is blank.Please provide a price for seats(\\d+)$")
	public void Admin_gets_message_Price_is_blank_Please_provide_a_price_for_seats(int arg1) throws Throwable {
		status(2, 2, "data");
	}

	@When("^Admin selects Seat type and Admin enters Price having alphabets and Admin clicks on Update button$")
	public void Admin_selects_Seat_type_and_Admin_enters_Price_having_alphabets_and_Admin_clicks_on_Update_button() throws Throwable {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(3, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(3,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^User gets message -Please enter a number(\\d+)$")
	public void User_gets_message_Please_enter_a_number(int arg1) throws Throwable {
	    status(3, 2, "data");
	}

	@When("^Admin enters Seat type and Admin enters Price having special cahracters and Admin clicks on Update button$")
	public void Admin_enters_Seat_type_and_Admin_enters_Price_having_special_cahracters_and_Admin_clicks_on_Update_button() throws Throwable {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(4, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(4,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^Admin gets message -Please enter a number(\\d+)$")
	public void Admin_gets_message_Please_enter_a_number(int arg1) throws Throwable {
	    status(4,2,"data");
	}

	@When("^User enters Seat type and user enters Price less than (\\d+) and user clicks on Update button$")
	public void User_enters_Seat_type_and_user_enters_Price_less_than_and_user_clicks_on_Update_button(int arg1) throws Throwable {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(5, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(5,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^User gets messages -Price must be greater than or equal to (\\d+)$")
	public void User_gets_messages_Price_must_be_greater_than_or_equal_to(int arg1) throws Throwable {
	    status(5, 2, "data");
	}

	@When("^User enters Seat type  and user enters Price greater than (\\d+) and user clicks on Update button$")
	public void User_enters_Seat_type_and_user_enters_Price_greater_than_and_user_clicks_on_Update_button(int arg1) throws Throwable {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		seattype.selectByVisibleText(read(6, 0, "data"));
		 driver.findElement(getlocator("price")).sendKeys(read(6,1,"data"));
		driver.findElement(getlocator("update")).click();
	}

	@Then("^User gets message -value(\\d+) must be less than or equal to (\\d+)$")
	public void User_gets_message_value_must_be_less_than_or_equal_to(int arg1, int arg2) throws Throwable {
	    status(6, 2, "data");
	}

	@When("^clicks the Seat type dropdown$")
	public void clicks_the_Seat_type_dropdown() throws Throwable {
		Select seattype = new Select(driver.findElement(getlocator("seat")));
		List<WebElement> dd=seattype.getOptions();
		String act=String.valueOf(dd.size());
		write(2, 2,act, "GUI");
	}

	@Then("^Users gets (\\d+) options - platinum, silver and gold$")
	public void Users_gets_options_platinum_silver_and_gold(int arg1) throws Throwable {
		status(2, 1, "GUI");
	}

	@When("^User clicks on Seat types dropdown$")
	public void User_clicks_on_Seat_types_dropdown() throws Throwable {
	    
	}

	@Then("^User gets to select only one options$")
	public void User_gets_to_select_only_one_options() throws Throwable {
	    
	}

	@When("^User counts number  of linkss$")
	public void User_counts_number_of_linkss() throws Throwable {
	  
	}

	@Then("^links should  be equal to (\\d+)$")
	public void links_should_be_equal_to(int arg1) throws Throwable {
	    
	}

	@When("^User counts no. of the dropdowns$")
	public void User_counts_no_of_the_dropdowns() throws Throwable {
	    
	}

	@Then("^no of dropdowns must be equal to (\\d+)$")
	public void no_of_dropdowns_must_be_equal_to(int arg1) throws Throwable {
	    
	}

	@When("^User counts no. of textboxes$")
	public void User_counts_no_of_textboxes() throws Throwable {
	    
	}

	@Then("^textboxes should  be equal to (\\d+)$")
	public void textboxes_should_be_equal_to(int arg1) throws Throwable {
	    
	}

	@When("^user counts total number of buttons in UpdatePrice page$")
	public void user_counts_total_number_of_buttons_in_UpdatePrice_page() throws Throwable {
	    
	}

	@Then("^B should  be equal to (\\d+)$")
	public void B_should_be_equal_to(int arg1) throws Throwable {
	    
	}

}
